75.68. Sistemas de soporte para celdas de producción flexible
=============================================================

Este repositorio toma la información original de gvgai, más información en los links que se encuentran más abajo.

Se han modificado algunos archivos para convertirlo en material de estudio. Y para uso como trabajo practico.


gvgai
=====

Code: https://github.com/rubenrtorrado/GVGAI_GYM

Main Page:  http://www.gvgai.net/

Google group: https://groups.google.com/forum/#!forum/the-general-video-game-competition
